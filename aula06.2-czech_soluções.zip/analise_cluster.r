#An�lise de Clusters

#Carregamento de Bibliotecas
library(RODBC)
library(magrittr)
library(cluster)

#Leitura de dados externos (de planilha)
conn <- odbcConnectExcel2007("analise_cluster.xlsx")
rawdata <- sqlFetch(conn,"analise_cluster")
odbcClose(conn)

#Obten��o dos campos num�ricos
summary(rawdata)
numdata <- rawdata[,c(3,6:10)]

#Tratamento de dados - elimina��o de NAs
numdata[is.na(numdata[,5]),5] <- 1 

#Gera��o de dados padronizados
scaledata <- as.matrix(scale(numdata))

#Visualiza��o inicial
boxplot(numdata)
boxplot(scaledata)


#Within group sum of averages
wss <- (nrow(numdata)-1)*sum(apply(numdata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(numdata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")


#Escolhendo 3 fatores para o k-means clustering
fit <- kmeans(scaledata,3)
plot(scaledata,col=fit$cluster,pch=15)

#Gr�fico dos pontos x 2 fatores ortogonais principais
clusplot(scaledata, fit$cluster, color=TRUE, shade=TRUE, 
         labels=2, lines=0)

