SELECT account.account_id AS conta,  
              SWITCH(cint(mid(client.birth_number,3,2))>=50,"F", cint(mid(client.birth_number,3,2)),"M") AS sex,
              cint(LEFT(client.birth_number,2)) AS idade,
              credit_card.type AS cartao,
              loan.status AS status_loan, loan.amount AS loan_am, 
              int(sum(transactions.amount)) AS trans_sum,
              demograph.A11 AS avg_sal, 
              IIF(demograph.A13=0 OR demograph.A12=0,1,demograph.A13/demograph.A12) as unemp_r, 
              cint(demograph.A14) AS entrep_no

FROM (((((account 
INNER JOIN disposition ON account.account_id = disposition.account_id) 
INNER JOIN credit_card ON disposition.disp_id = credit_card.disp_id) 
INNER JOIN client ON disposition.client_id = client.client_id) 
INNER JOIN demograph ON client.district_id = demograph.A1) 
INNER JOIN transactions ON account.account_id = transactions.account_id)
INNER JOIN loan ON account.account_id = loan.account_id

WHERE disposition.type = "OWNER" AND mid(transactions.date,1,2)>97

GROUP BY account.account_id, disposition.type, credit_card.type, cint(LEFT(client.birth_number,2)),
                   SWITCH(cint(mid(client.birth_number,3,2))>=50,"F",cint(mid(client.birth_number,3,2)),"M"),
                   demograph.A11, demograph.A13, demograph.A12, demograph.A14, mid(transactions.date,1,2),
                   loan.status, loan.amount


